from typing import Callable

import numpy as np

from common import T
from .block_fista import FISTA
from .block_ista import ISTA


def get_model_list():
    return [
        'FISTA',
        'ISTA'
    ]


class ModelFactory:

    @staticmethod
    def create_FISTA(A: np.ndarray, tau: T, prox_func: Callable):
        return FISTA(A, tau, prox_func)

    @staticmethod
    def create_ISTA(A: np.ndarray, tau: T, prox_func: Callable):
        return ISTA(A, tau, prox_func)

    def create_model(self, model_name: str, *args, **kwargs):
        assert model_name in get_model_list()
        return getattr(self, f'create_{model_name}')(*args, **kwargs)
