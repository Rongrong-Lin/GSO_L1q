# ** coding: utf-8 **
"""
@Author: Zhihong Li, Rongrong Lin
@date: 2020/11/25
@description: Experiment1: different sparse levels.
@version: 2.0
"""
import numpy as np
import pandas as pd

from config import init_log
from create_data import create_sc_dataset
from experiment.exp_settings import exp1_opts
from loss import objective_val
from models import ModelFactory
from prox.prox_cl import *
from report import init_settings
from utils import save_df

opts = exp1_opts
init_log(opts)
reporter = init_settings(opts, None)


def run():
    for persettings in opts.dynamic_settings:
        success_times = 0
        opts.sparsity = persettings.sparsity
        opts.logger('\nUsing sparsity: {}\n'.format(opts.sparsity))
        for repeat_times in range(1, opts.repeat_times + 1):
            # Create data
            (x_test, d_test), A, b = create_sc_dataset(opts=opts)
            gamma = 1 / np.linalg.norm(A, 2) ** 2
            # ['ProxL2_1', 'ProxL2_2over3', 'ProxL2_1over2', 'ProxL1_1over2', 'ProxL1_2over3', 'ProxL1_1over2_FixParams', 'ProxL1_2over3_FixParams']
            # prox_func = ProxL2_1(opts.n, opts.gLen)
            prox_func = ProxL1_2over3_FixParams(opts.n, opts.gLen, opts.data_size,nu=opts.tau*gamma)

            desc = opts.algorithm + '_' + prox_func.name()
            opts.logger('\n Running {} with {}...\n'.format(opts.algorithm, prox_func.name()))

            # Create model
            model = ModelFactory().create_model(
                model_name=opts.algorithm, A=A, prox_func=prox_func, tau=opts.tau)
            model(d_test, K=opts.K)
            # for i in range(1, opts.K):
            #     loss = objective_val(model.iter_history[i], d_test, x_test, objective='RELATIVE')
            #     #print(loss)
            loss = objective_val(model.iter_history[-1], d_test, x_test, objective='RELATIVE')
            opts.logger('Iteration: {}, Testing Loss: {}'.format(opts.K, loss))
            if loss < 0.005:
                success_times += 1
            df = pd.DataFrame([model.iter_history[-1].reshape(-1).T, x_test.reshape(-1).T]).T
            df.columns = ['x_pred', 'x_gt']
            save_df(df, opts.save_dir + f'/sparsity{opts.sparsity}_repeat{repeat_times}.xlsx',
                    f"{desc}_{opts.sparsity}_{repeat_times}")
        setattr(opts, f'sparsity_{opts.sparsity}_success_times', success_times)
        setattr(opts, f'sparsity_{opts.sparsity}_success_rate', success_times / opts.repeat_times)
        reporter.save_inf(f'\n\nSparse Level --> {opts.sparsity / (opts.n / opts.gLen)}\n\n')
        reporter.save_inf(f'sparsity_{opts.sparsity}_success_times{success_times}')
        reporter.save_inf(f'sparsity_{opts.sparsity}_success_rate{success_times / opts.repeat_times}')
        reporter.save_inf(f'\n\nFinish -sparsity-{opts.sparsity}-repeat-{opts.repeat_times}\n\n')


run()
