# ** coding: utf-8 **
"""
@Author: Zhihong Li, Rongrong Lin
@date: 2020/11/25
@description: Create data for Group Sparse.
@version: 2.0
"""
import numpy as np
from sklearn.preprocessing import normalize


def create_sc_dataset(opts=None) -> (np.ndarray, np.ndarray, np.ndarray, np.ndarray):
    """
    :param opts: options in config.py
    :return:  (x_tensor, d_tensor), A, b
    """
    if opts is None:
        from config import Opts
        opts = Opts
    np.random.seed(opts.data_seed)
    m, n = opts.m, opts.n
    sparsity = opts.sparsity
    gLen = opts.gLen
    gNo = int(opts.n / gLen)

    test_size = opts.data_size

    A = np.random.normal(size=(m, n))
    A = normalize(A, norm='l2', axis=0)

    gNo1 = np.arange(1, gNo + 1)

    c = np.random.normal(0, 1, (test_size, n, 1))

    # Generate inter group
    # for sample in range(c.shape[0]):
    #     Bs = np.zeros((n, 1))
    #     ActInd = np.random.choice(gNo1, sparsity, replace=False)
    #     for i in range(sparsity):
    #         Bs[((ActInd[i] - 1) * gLen):(ActInd[i] * gLen)] = np.ones((gLen, 1))
    #     c[sample] = Bs * c[sample]

    # Generate intra group and inter group
    for sample in range(c.shape[0]):
        Bs = np.zeros((n, 1))
        ActInd = np.random.choice(gNo1, sparsity, replace=False)

        for i in range(sparsity):
            start = (ActInd[i] - 1) * gLen
            end = ActInd[i] * gLen


            group_size = gLen
            num_nonzero = int(round(group_size * 0.5))
            num_nonzero = max(1, num_nonzero)

            nonzero_indices = np.random.choice(
                group_size,
                size=num_nonzero,
                replace=False
            )

            group_mask = np.zeros((group_size, 1))
            group_mask[nonzero_indices] = 1

            Bs[start:end] = group_mask

        c[sample] = Bs * c[sample]

    if opts.noise_params is not None:
        noise = make_noise_data(opts)
    else:
        noise = 0

    b = A.dot(c) + noise

    # # Transform x and d into tensors
    x_tensor = c[:, :, 0]
    d_tensor = b[:, :, 0].T
    return (x_tensor, d_tensor), A, b  # 测试数据集，观测矩阵A，观测组信号b


def make_noise_data(opts):
    noise_params = opts.noise_params
    m = opts.m
    loc, scale = noise_params.loc, noise_params.scale
    if noise_params.dist == 'normal':
        noise = noise_params.sig * np.random.normal(loc, scale, (m, 1, 1))
    elif noise_params.dist == 'laplace':
        noise = noise_params.sig * np.random.laplace(loc, scale, (m, 1, 1))
    else:
        noise = noise_params.sig * np.random.rand(m)
    print(f'\n-----{noise_params.dist} noise added-----\n')
    return noise
