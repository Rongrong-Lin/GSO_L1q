# ** coding: utf-8 **
import numpy as np
from prox.prox_cl import *

prox_l1_1over2 = ProxL1_1over2(n=2, gLen=2, num_samples=1)


y= np.array([0.24756257, 0.14068853, 0.1378746 , 0.11871051, 0.07287179,
   0.05138428, 0.0107804 , 0.00406851])
l1_1over2=ProxL1_2over3(n=len(y),gLen=len(y),num_samples=1)
l1_1over2.prox(y,v=0.1)