import numpy as np
import matplotlib.pyplot as plt

# 生成示例数据
np.random.seed(42)
dimensions = np.arange(1024)  # 0-1023共1024个维度

# 创建模拟信号
true_signal = np.sin(dimensions/64) + 0.1*np.random.randn(1024)
recovered1 = true_signal + 0.2*np.random.randn(1024)
recovered2 = true_signal + 0.3*np.random.randn(1024) + 0.5

# 设置画布
plt.figure(figsize=(16, 8), dpi=100)
plt.rcParams['font.sans-serif'] = ['Arial']  # 设置英文字体

# 绘制离散点
plt.scatter(dimensions, true_signal,
           s=8,          # 点大小
           alpha=0.5,    # 透明度
           c='blue',     # 颜色
           marker='o',   # 点形状
           edgecolor='none',
           label='True Signal')

plt.scatter(dimensions, recovered1,
           s=10,
           alpha=0.4,
           c='red',
           marker='x',  # 交叉形标记
           linewidths=0.8,
           label='Recovered 1')

plt.scatter(dimensions, recovered2,
           s=10,
           alpha=0.4,
           c='green',
           marker='^',  # 三角形标记
           edgecolors='darkgreen',
           label='Recovered 2')

# 坐标轴设置
plt.xlim(-50, 1074)  # 留出边界空白
plt.ylim(-3, 4)
plt.xlabel("Dimension Index", fontsize=12)
plt.ylabel("Signal Strength", fontsize=12)
plt.title("1024D Signal Scatter Plot Comparison", fontsize=14)

# 优化刻度显示
plt.xticks(np.arange(0, 1025, 128))  # 每128个维度显示刻度
plt.gca().tick_params(axis='both', which='major', labelsize=9)

# 添加辅助元素
plt.grid(alpha=0.2, linestyle='--')
plt.legend(loc='upper right', markerscale=2)  # 放大图例中的标记

# 调整边距
plt.subplots_adjust(left=0.06, right=0.98, top=0.94, bottom=0.1)
plt.show()