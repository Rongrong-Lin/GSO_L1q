# Experiment Settings
We consider to solve a problem as follows ( Problem 1.1 )

![](\doc\problem.jpg)

We apply the proximal gradient algorithm to solve the ℓp,q regularization
problem (1.1), which generates a sequence {x
(k)} via the following iteration:

![ISTA](\doc\ista.jpg)

- Gaussian ensemble **$A\in R^{mxl}$ satisfying A^TA=I**
- Fixing **m=256, l=1024** in all experiments 
- Fixing group length = 8, therefore the number of groups is 1024/8 = 128
- 
# Experiment 1 
**Convergence results and recovery rates for different sparsity levels**

 Sparse rate=sparsity/number of groups
We list different kinds of sparsity and Sparse rate.

| Sparsity | Sparse Level |
|----------|--------------|
| 1        | 0.78%        |
| 2        | 1.56%        |
| 3        | 2.34%        |
| 4        | 3.13%        |
| 5        | 3.91%        |
| 6        | 4.69%        |
| 7        | 5.47%        |
| 8        | 6.25%        |
| 9        | 7.03%        |
| 10       | 7.81%        |
| 11       | 8.59%        |
| 12       | 9.38%        |
| 13       | 10.16%       |
| 14       | 10.94%       |
| 15       | 11.72%       |
| 16       | 12.50%       |
| 17       | 13.28%       |
| 18       | 14.06%       |
| 19       | 14.84%       |
| 20       | 15.63%       |
| 21       | 16.41%       |
| 22       | 17.19%       |
| 23       | 17.97%       |
| 24       | 18.75%       |
| 25       | 19.53%       |
| 26       | 20.31%       |
| 27       | 21.09%       |
| 28       | 21.88%       |
| 29       | 22.66%       |
| 30       | 23.44%       |
