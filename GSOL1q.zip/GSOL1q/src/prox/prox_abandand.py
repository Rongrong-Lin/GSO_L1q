# ** coding: utf-8 **
import numpy as np

from common import T
from config import Opts

import warnings
warnings.warn('`prox_abandand.py` is deprecated. Use `prox.py` instead.', DeprecationWarning)

# ---------proximal operator 中带org的是v1.0版本）
# Group proximal operator
def group_l2_1(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)
    norm_x = norms

    tao = np.where(norm_x <= v, 0.0, (1 - v / norm_x))

    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l2_2over3(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    # 提取每个子向量并计算范数
    norms = np.stack([np.linalg.norm(subvec, axis=1) for subvec in x_subvectors], axis=0)

    t = (1 / 16 + np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3) + (
            1 / 16 - np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3)
    tao = np.where(norms <= 2 * ((2 / 3) * v ** 0.75), 0.0,
                   (1.0 / 8.0) * (np.sqrt(2.0 * t) + (
                       np.sqrt(2.0 / np.sqrt(2.0 * t) - 2.0 * t))) ** 3)

    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l2_1over2(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    # 提取每个子向量并计算norm
    norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)
    norm_x = norms

    break_point = 1.5 * v ** (2 / 3)
    tao = np.where(norm_x <= break_point, 0.0, (2 / 3) * (1.0 + np.cos((2 / 3) *
                                                                       (np.arccos(-3 ** 1.5 / 4 * v * (norm_x ** -1.5)
                                                                                  )))))
    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l1_1over2(x: np.ndarray, nu: T):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors_sample = np.split(x, 1, axis=0)

    res = []
    for i in x_subvectors_sample:
        x_subvectors_group = np.split(i, num_subvectors, axis=1)
        for persample_group in x_subvectors_group:
            res.append(Proxl1_1over2.prox(persample_group[0], nu))
    return np.array(res).reshape(x.shape[0], x.shape[1])


def group_l1_2over3(x: np.ndarray, nu: T):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors_sample = np.split(x, 1, axis=0)

    res = []
    for i in x_subvectors_sample:
        x_subvectors_group = np.split(i, num_subvectors, axis=1)
        for persample_group in x_subvectors_group:
            res.append(Proxl1_2over3.prox(persample_group[0], nu))
    return np.array(res).reshape(x.shape[0], x.shape[1])


class Proxl1_1over2:

    @classmethod
    def obj(cls, y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
        return nu * np.power(ytilde.sum(), 1 / 2) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

    @classmethod
    def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
        # 记录顺序和绝对值，用于后续计算
        sign_x = np.sign(x)
        indices = np.argsort(x.__abs__())[::-1]
        sorted_indices = np.argsort(indices)

        # 使用索引获取排序后的矩阵
        y = x.__abs__()[indices]  # STANDARD先绝对值，后降序排序

        condition_1 = 3 * nu ** (2 / 3) / (2 ** (4 / 3))
        condition_2 = 1.5 * nu ** (2 / 3)

        if y.sum() <= condition_1:  # case1
            return x * 0
        elif y[-1] > condition_2:  # case2
            ytilde = y - cls.calculate_cs_sort(y, nu)
            return cls.rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
        else:
            # Search s
            s_list = [np.zeros_like(y)]  # 0向量
            s_list.extend(cls.loop_search_s(y, nu))  # 通过搜索找的S集合
            # s_list2 = [np.zeros_like(y)]  # 0向量
            # s_list2.extend(cls.loop_search_s_org(y, nu))  # 通过搜索找的S集合
            Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
            if y[0] <= condition_2:  # case 3
                return cls.rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
            else:  # case4
                if len(s_list) > 1:
                    s_list.pop(0)
                    Js_list.pop(0)
                return cls.rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)

    @classmethod
    def rearrange_org(cls, ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
        return ytilde[sorted_indices] * sign

    @classmethod
    def loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
        n = y.shape[0]
        # Search s
        s_list = []

        for s in range(1, n):

            y_l1 = y[:s].sum()
            if y_l1 < cls.calculate_condition3(v=nu, q=1 / 2, s=s):
                continue
            cs = cls.calculate_cs_sort(y[:s], nu)

            if y_l1 >= (3 * nu ** (2 / 3) * (0.5 ** (4 / 3))) * s ** (2 / 3) and y[s - 1] > cs >= y[s]:
                s_list.append(np.maximum(y - cs, 0))
                #print(s)
        if y.sum() >= cls.calculate_condition3(v=nu, q=1 / 2, s=n):

            cn = cls.calculate_cs_sort(y, nu)
            if y.sum() >= (3 * nu ** (2 / 3) * (0.5 ** (4 / 3))) * n ** (2 / 3) and y[- 1] > cn:
                s_list.append(np.maximum(y - cn, 0))
             #   print(n)
        return s_list


    @classmethod
    def calculate_cs_sort(cls, ys: np.ndarray, nu: np.ndarray) -> np.ndarray:
        """
        y -> y_s
        :param y:
        :param nu:
        :param s:
        :return:
        """
        ys_l1 = ys.sum()
        return (np.sqrt(3) * nu) / (
                4 * np.sqrt(ys_l1) * np.cos(
            (1 / 3) * np.arccos(-3 * np.sqrt(3.0) * nu * len(ys) * np.power(ys_l1, -3 / 2) / 4)))

    @classmethod
    def calculate_condition3(cls, v, q, s):
        return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))


class Proxl1_2over3():

    @classmethod
    def obj(cls, y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
        return nu * np.power(ytilde.sum(), 2 / 3) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

    @classmethod
    def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
        # 记录顺序和绝对值，用于后续计算
        sign_x = np.sign(x)

        indices = np.argsort(x.__abs__())[::-1]
        sorted_indices = np.argsort(indices)

        # 使用索引获取排序后的矩阵
        y = x.__abs__()[indices]

        condition_1 = 4 * ((2 / 9) ** 0.75) * (nu ** 0.75)
        condition_2 = 2 * (2 * nu / 3) ** 0.75

        if y.sum() <= condition_1:  # case1
            return x * 0
        elif y.min() > condition_2:  # case2
            ytilde = y - cls.calculate_cs_sort(y, nu)
            return cls.rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
        else:
            # Search s
            s_list = [np.zeros_like(y)]
            s_list.extend(cls.loop_search_s(y, nu))
            Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
            if np.max(y) <= condition_2:  # case 3
                return cls.rearrange_org(s_list[np.argsort(Js_list)[0]], sorted_indices, sign_x)
            else:  # case4
                if len(s_list) > 1:
                    s_list.pop(0)
                    Js_list.pop(0)
                return cls.rearrange_org(s_list[np.argsort(Js_list)[0]], sorted_indices, sign_x)

    @classmethod
    def rearrange_org(cls, ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
        return ytilde[sorted_indices] * sign

    @classmethod
    def calculate_condition3(cls, v, q, s):
        return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))


    @classmethod
    def loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
        n = y.shape[0]
        # Search s
        s_list = []

        for s in range(1, n):
            y_l1 = y[:s].sum()
            if y_l1 < cls.calculate_condition3(v=nu, q=2 / 3, s=s):
                continue
            cs = cls.calculate_cs_sort(y[:s], nu)
            if y_l1 >= ((4 / 3) * nu ** 0.75 * (2 ** 0.75 / 3 ** 0.5)) * s * 0.75 and y[s - 1] > cs >= y[s]:
                s_list.append(np.maximum(y - cs, 0))
        if y.sum() >= cls.calculate_condition3(v=nu, q=2 / 3, s=n):
            cn = cls.calculate_cs_sort(y, nu)
            if y.sum() >= ((4 / 3) * nu ** 0.75 * (2 ** 0.75 / 3 ** 0.5)) * n * 0.75 and y[- 1] > cn:
                s_list.append(np.maximum(y - cn, 0))
        return s_list

    @classmethod
    def calculate_cs_sort(cls, ys: np.ndarray, nu: np.ndarray) -> np.ndarray:
            ys_l1 = ys.sum()

            part_alpha = np.sqrt(ys_l1 ** 4 / 256 - 8 * (nu ** 3) * (len(ys) ** 3) / 729)
            # part_alpha = np.sqrt(np.clip(ys_l1 ** 4 / 256 - 8 * (nu ** 3) * (len(ys) ** 3) / 729,a_min=1e-16,a_max=1000))
            alpha_s = (ys_l1 ** 2 / 16 + part_alpha) ** (1 / 3) + (ys_l1 ** 2 / 16 - part_alpha) ** (1 / 3)
            sqrt_2alpha = np.sqrt(2 * alpha_s)
            return (4 * nu / 3) * 1 / (sqrt_2alpha + np.sqrt(2 * ys_l1 / sqrt_2alpha - 2 * alpha_s))
