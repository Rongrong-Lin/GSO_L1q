import numpy as np

from common import T
from prox import GroupProximalOperator
import warnings

__all__ = ['ProxL2_1', 'ProxL2_2over3', 'ProxL2_1over2', 'ProxL1_1over2', 'ProxL1_2over3', 'ProxL1_1over2_FixParams',
           'ProxL1_2over3_FixParams']


# Group proximal operators
class ProxL2_1(GroupProximalOperator):
    def __init__(self, n: int, gLen: int):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        raise NotImplementedError('Not implemented yet')

    def prox(self, x: np.ndarray, v: T, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)
        tao = np.where(norms <= v, 0.0, (1 - v / norms))
        x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(self.num_subvectors)]
        return self._concentrate_vectors(x_subvectors)

    @classmethod
    def name(cls) -> str:
        return 'group_l2_1'

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x, self.num_subvectors, axis=1)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(x_subvectors, axis=1)


class ProxL2_2over3(GroupProximalOperator):
    def __init__(self, n: int, gLen: int):
        self.n = n
        self.gLen = gLen
        self.num_subvectors = self.get_num_subvectors(n, gLen)

    @classmethod
    def name(cls) -> str:
        return 'group_l2_2over3'

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        raise NotImplementedError('Not implemented yet')

    def prox(self, x: np.ndarray, v: T, *args, **kwargs) -> np.ndarray:
        # Split the vector into subvectors
        x_subvectors = self._split_vectors(x)
        # Compute the norms of each subvector

        norms = np.stack([np.linalg.norm(subvec, axis=1) for subvec in x_subvectors], axis=0)

        # Compute the Proximal Operator for each subvector
        t = (1 / 16 + np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3) + (
                1 / 16 - np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3)
        tao = np.where(norms <= 2 * ((2 / 3) * v ** 0.75), 0.0,
                       (1.0 / 8.0) * (np.sqrt(2.0 * t) + (
                           np.sqrt(2.0 / np.sqrt(2.0 * t) - 2.0 * t))) ** 3)
        x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(self.num_subvectors)]

        # Concatenate the subvectors
        return self._concentrate_vectors(x_subvectors)

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x, self.num_subvectors, axis=1)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(x_subvectors, axis=1)


class ProxL2_1over2(GroupProximalOperator):
    def __init__(self, n: int, gLen: int):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        raise NotImplementedError('Not implemented yet')

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)

        norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)

        break_point = 1.5 * v ** (2 / 3)
        tao = np.where(norms <= break_point, 0.0, (2 / 3) * (1.0 + np.cos((2 / 3) *
                                                                          (np.arccos(
                                                                              -3 ** 1.5 / 4 * v * (norms ** -1.5)
                                                                          )))))
        x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(self.num_subvectors)]

        return self._concentrate_vectors(x_subvectors)

    @classmethod
    def name(cls):
        return 'group_l2_1over2'

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x, self.num_subvectors, axis=1)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(x_subvectors, axis=1)


class ProxL1_1over2(GroupProximalOperator):
    def __init__(self, n: int, gLen: int, num_samples: int = 1):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)
        self.num_samples: int = num_samples

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        return super().obj(x, xtilde, nu)

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        return np.concatenate([self.L1_1over2_part.prox(x_sub, v) for x_sub in x_subvectors]).reshape(self.num_samples,
                                                                                                      -1)

    @classmethod
    def name(cls):
        return 'group_l1_1over2'

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x.flatten(), self.num_subvectors * self.num_samples)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        raise NotImplementedError('You dont need to call this method')

    class L1_1over2_part:

        @staticmethod
        def obj(y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
            return nu * np.power(ytilde.sum(), 1 / 2) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

        @classmethod
        def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
            # 记录顺序和绝对值，用于后续计算

            x_abs = np.abs(x)

            condition_1 = 3 * nu ** (2 / 3) / (2 ** (4 / 3))

            ys_l1 = x_abs.sum()
            # ys_l1 = y.sum()
            if ys_l1 <= condition_1:  # case1
                return np.zeros_like(x)
            else:
                condition_2 = 1.5 * nu ** (2 / 3)
                sign_x = np.sign(x)

                # if y[-1] > condition_2:  # case2
                indices = np.argsort(-x_abs)
                y = x_abs[indices]
                if y[-1] > condition_2:  # case2
                    # Method 1
                    # ytilde = y - cls._calculate_cs(ys_l1, nu, len(y))
                    # return #cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
                    # Method 2
                    return (x_abs - cls._calculate_cs(ys_l1, nu, len(x))) * sign_x
                else:
                    sorted_indices = np.argsort(indices)
                    # Search s
                    s_list = [np.zeros_like(y)]
                    s_list.extend(cls._loop_search_s(y, nu))
                    Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
                    if y[0] <= condition_2:  # case 3
                        return cls._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
                    return cls._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

        @staticmethod
        def _rearrange_org(ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
            return ytilde[sorted_indices] * sign

        @classmethod
        def _loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
            # Search s
            y_l1_array = y.cumsum()

            s_arange = np.arange(1, len(y_l1_array) + 1)
            cs_array = cls._calculate_cs(y_l1_array, nu, s_arange)  # y -> y_s
            y_plus = np.append(y, -1)[1:]

            condition4 = (3 * nu ** (2 / 3) * (0.5 ** (4 / 3))) * s_arange ** (2 / 3)

            res = (y_l1_array >= condition4) & (y_l1_array >= cls._calculate_condition3(v=nu, q=1 / 2, s=s_arange)) & (
                    y > cs_array) & (cs_array >= y_plus)
            return [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]

        @staticmethod
        def _calculate_cs(y_l1_array: np.ndarray, nu: np.ndarray, s) -> np.ndarray:
            return (np.sqrt(3.0) * nu) / (
                    4 * np.sqrt(y_l1_array) * np.cos(
                (1 / 3) * np.arccos(-3 * np.sqrt(3.0) * nu * s * np.power(y_l1_array, -3 / 2) / 4)))

        @staticmethod
        def _calculate_condition3(v, q, s):
            return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))


class ProxL1_2over3(GroupProximalOperator):
    def __init__(self, n: int, gLen: int, num_samples: int = 1):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)
        self.num_samples: int = num_samples

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        return super().obj(x, xtilde, nu)

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        return np.concatenate([self.L1_2over3_part.prox(x_sub, v) for x_sub in x_subvectors]).reshape(self.num_samples,
                                                                                                      -1)

    @classmethod
    def name(cls):
        return 'group_l1_2over3'

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x.flatten(), self.num_subvectors * self.num_samples)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        raise NotImplementedError('You dont need to call this method')

    class L1_2over3_part():

        @staticmethod
        def obj(y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
            return nu * np.power(ytilde.sum(), 2 / 3) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

        @classmethod
        def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
            # 记录顺序和绝对值，用于后续计算

            x_abs = np.abs(x)

            # 使用索引获取排序后的矩阵

            condition_1 = 4 * ((2 / 9) ** 0.75) * (nu ** 0.75)

            ys_l1 = x_abs.sum()

            if ys_l1 <= condition_1:  # case1
                return np.zeros_like(x)
            else:

                condition_2 = 1.5 * nu ** (2 / 3)
                sign_x = np.sign(x)

                # if y[-1] > condition_2:  # case2
                indices = np.argsort(-x_abs)
                y = x_abs[indices]

                if y[-1] > condition_2:  # case2
                    # ytilde = y - cls._calculate_cs(y_l1, nu, len(y))
                    # return cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
                    return (x_abs - cls._calculate_cs(ys_l1, nu, len(x))) * sign_x
                else:
                    # Search s
                    sorted_indices = np.argsort(indices)
                    s_list = [np.zeros_like(y)]
                    s_list.extend(cls._loop_search_s(y, nu))
                    Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
                    if y[0] <= condition_2:  # case 3
                        return cls._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
                    return cls._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

        @staticmethod
        def _rearrange_org(ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
            return ytilde[sorted_indices] * sign

        @classmethod
        def _loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
            # Search s
            y_l1_array = y.cumsum()

            s_arange = np.arange(1, len(y_l1_array) + 1)
            cs_array = cls._calculate_cs(y_l1_array, nu, s_arange)
            y_plus = np.append(y, -1)[1:]

            condition4 = ((4 / 3) * nu ** 0.75 * (2 ** 0.75 / 3 ** 0.5)) * s_arange * 0.75
            res = (y_l1_array >= condition4) & (y_l1_array >= cls._calculate_condition3(v=nu, q=2 / 3, s=s_arange)) & (
                    y > cs_array) & (cs_array >= y_plus)
            return [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]

        @staticmethod
        def _calculate_condition3(v, q, s):
            return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))

        @staticmethod
        def _calculate_cs(y_l1_array: np.ndarray, nu: np.ndarray, s) -> np.ndarray:
            part_alpha = np.sqrt(y_l1_array ** 4 / 256 - 8 * (nu ** 3) * (s ** 3) / 729)
            alpha_s = (y_l1_array ** 2 / 16 + part_alpha) ** (1 / 3) + (y_l1_array ** 2 / 16 - part_alpha) ** (1 / 3)
            sqrt_2alpha = np.sqrt(2 * alpha_s)
            return (4 * nu / 3) * 1 / (sqrt_2alpha + np.sqrt(2 * y_l1_array / sqrt_2alpha - 2 * alpha_s))


class ProxL1_1over2_FixParams(ProxL1_1over2):
    """
    Calculate Proximal L1,1/2 (p=1,q=1/2) with fixing params.
    """

    def __init__(self, n: int, gLen: int, num_samples: int = 1, nu: T = None):
        super(ProxL1_1over2_FixParams, self).__init__(n, gLen, num_samples)
        assert nu is not None, "please input nu"
        self.part = self.L1_1over2_part(gLen, nu)

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        return np.concatenate([self.part.prox(x_sub, v) for x_sub in x_subvectors]).reshape(self.num_samples, -1)

    class L1_1over2_part(ProxL1_1over2.L1_1over2_part):  # 不继承可提速0.2s
        def __init__(self, gLen, nu):
            self.condition1 = 3 * nu ** (2 / 3) / (2 ** (4 / 3))
            self.condition2 = 1.5 * nu ** (2 / 3)
            self.s_arange = np.arange(1, gLen + 1)
            self.condition3 = self._calculate_condition3(v=nu, q=1 / 2, s=self.s_arange)
            self.condition4 = (3 * nu ** (2 / 3) * (0.5 ** (4 / 3))) * self.s_arange ** (2 / 3)

        def prox(self, x: np.ndarray, nu: T) -> np.ndarray:
            x_abs = np.abs(x)
            ys_l1 = x_abs.sum()
            if ys_l1 <= self.condition1:  # case1
                return np.zeros_like(x)
            else:
                sign_x = np.sign(x)
                indices = np.argsort(-x_abs)
                y = x_abs[indices]
                if y[-1] > self.condition2:  # case2
                    # Method 1
                    # ytilde = y - cls._calculate_cs(ys_l1, nu, len(y))
                    # return #cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
                    # Method 2
                    return (x_abs - self._calculate_cs(ys_l1, nu, len(x))) * sign_x
                else:
                    sorted_indices = np.argsort(indices)
                    # Search s
                    s_list = [np.zeros_like(y)]
                    s_list.extend(self._loop_search_s(y, nu))
                    Js_list = [self.obj(y, per_ytilde, nu) for per_ytilde in s_list]
                    if y[0] <= self.condition2:  # case 3
                        return self._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
                    return self._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

        def _loop_search_s(self, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
            # Search s
            y_l1_array = y.cumsum()

            cs_array = self._calculate_cs(y_l1_array, nu, self.s_arange)  # y -> y_s
            y_plus = np.append(y, -1)[1:]

            res = (y_l1_array >= self.condition4) & (y_l1_array >= self.condition3) & (
                    y > cs_array) & (cs_array >= y_plus)
            return [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]


class ProxL1_2over3_FixParams(ProxL1_2over3):
    """
     Calculate Proximal L1,2/3 (p=1,q=2/3) with fixing params.
     """

    def __init__(self, n: int, gLen: int, num_samples: int = 1, nu: T = None):
        super(ProxL1_2over3_FixParams, self).__init__(n, gLen, num_samples)
        assert nu is not None, "please input nu"
        self.part = self.L1_2over3_part(gLen, nu)

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        return np.concatenate([self.part.prox(x_sub, v) for x_sub in x_subvectors]).reshape(self.num_samples, -1)

    class L1_2over3_part(ProxL1_2over3.L1_2over3_part):  # 不继承可提速0.2s
        def __init__(self, gLen, nu):
            self.condition1 = 4 * ((2 / 9) ** 0.75) * (nu ** 0.75)
            self.condition2 = 1.5 * nu ** (2 / 3)
            self.s_arange = np.arange(1, gLen + 1)
            self.condition3 = self._calculate_condition3(v=nu, q=2 / 3, s=self.s_arange)
            self.condition4 = ((4 / 3) * nu ** 0.75 * (2 ** 0.75 / 3 ** 0.5)) * self.s_arange * 0.75

        def prox(self, x: np.ndarray, nu: T) -> np.ndarray:
            x_abs = np.abs(x)
            ys_l1 = x_abs.sum()
            if ys_l1 <= self.condition1:  # case1
                return np.zeros_like(x)
            else:
                sign_x = np.sign(x)
                indices = np.argsort(-x_abs)
                y = x_abs[indices]
                if y[-1] > self.condition2:  # case2
                    # ytilde = y - cls._calculate_cs(y_l1, nu, len(y))
                    # return cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
                    return (x_abs - self._calculate_cs(ys_l1, nu, len(x))) * sign_x
                else:
                    # Search s
                    sorted_indices = np.argsort(indices)
                    s_list = [np.zeros_like(y)]
                    s_list.extend(self._loop_search_s(y, nu))
                    Js_list = [self.obj(y, per_ytilde, nu) for per_ytilde in s_list]
                    if y[0] <= self.condition2:  # case 3
                        return self._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
                    return self._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

        def _loop_search_s(self, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
            # Search s
            y_l1_array = y.cumsum()
            cs_array = self._calculate_cs(y_l1_array, nu, self.s_arange)
            y_plus = np.append(y, -1)[1:]

            res = (y_l1_array >= self.condition4) & (y_l1_array >= self.condition3) & (
                    y > cs_array) & (cs_array >= y_plus)
            return [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]
