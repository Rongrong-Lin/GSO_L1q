import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def plot_fig(path: str):
    try:
        df = pd.read_excel(path)
        df.columns = ['Sparsity','Sparse-Level',r"$\ell_{1,1/2}$", r"$\ell_{1,2/3}$", r"$\ell_{2,1}$", r"$\ell_{2,1/2}$", r"$\ell_{2,2/3}$"]
    except:
        raise pd.errors.DataError("Failed to read file")
    x = list(range(len(df)))
    #for i in df.columns[2:].to_list():
    plt.plot(df['Sparse-Level']*100, df[r"$\ell_{1,1/2}$"], label=r"$\ell_{1,1/2}$",color='r',marker='o',linestyle='--')
    plt.plot(df['Sparse-Level']*100, df[r"$\ell_{1,2/3}$"], label=r"$\ell_{1,2/3}$",color='b',marker='o',linestyle='--')
    plt.plot(df['Sparse-Level']*100, df[r"$\ell_{2,1}$"], label=r"$\ell_{2,1}$",color='black',marker='*',linestyle='--')
    plt.plot(df['Sparse-Level']*100, df[r"$\ell_{2,1/2}$"], label=r"$\ell_{2,1/2}$",color='orange',marker='x',linestyle='--')
    plt.plot(df['Sparse-Level']*100, df[r"$\ell_{2,2/3}$"], label=r"$\ell_{2,2/3}$",color='g',marker='.',linestyle='--')
    plt.legend()
    plt.xticks(ticks=np.linspace(0, 25, 6), labels=['0%', '5%', '10%', '15%', '20%', '25%'])

    plt.show()
    return df


path = 'D:\PythonPrograms\group_optimize_lpq\exp\exp.xlsx'
plot_fig(path)
