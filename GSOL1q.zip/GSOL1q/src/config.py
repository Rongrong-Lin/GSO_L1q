# ** coding: utf-8 **
import os
from typing import Optional

from munch import DefaultMunch

import utils
from common import T
from common.enum import DistributionEnum


class NoiseParams(DefaultMunch):
    loc: int = 0
    scale: float = 1
    sig: float = 0.001
    dist: DistributionEnum = DistributionEnum.RAND  # NORMAL


class Opts(DefaultMunch):
    description: str = 'Configurations for Group Sparse experiment with FISTA'

    # Problem and Solve Settings (Problem dependent)
    K: int = 1000  # Total Iterations
    objective: str =  'RELATIVE'  # Loss Function

    tau: T = 0.01  # 0.5  # 'Parameter for reg. term in the objective function'
    m: int = 256  # 'Number of rows in matrix A'
    n: int = 1024  # 'Number of cols in matrix A'

    data_size: int = 1  # 'Number of num_samples'

    # Generate Data Settings
    dist: str = 'normal'  # 'Distribution of entries in the matrix A'

    sparsity: int = 17  # 8# 'Sparsity'
    gLen: int = 8  # 16# 'Length of each group

    data_seed: int = 2  # 2  # 'Seed for generating data'

    # Logging Settings
    logger = None
    save_dir: str = '../output'  # Save directory

    plot_figs: bool = True  # 'Plot figures'

    noise_params: Optional[NoiseParams] = NoiseParams()


def init_log(opts: Opts):
    # Save directory
    if not os.path.isdir(opts.save_dir):
        os.makedirs(opts.save_dir)

    # Logging file
    logger_file = os.path.join(opts.save_dir, 'output.log')
    opts.logger = utils.setup_logger(logger_file)
    opts.logger('Checkpoints will be saved to directory `{}`'.format(opts.save_dir))
    opts.logger('Log file for training will be saved to file `{}`'.format(logger_file))
    opts.logger('Using tau: {}'.format(opts.tau))  # Output the tau used in current exp
