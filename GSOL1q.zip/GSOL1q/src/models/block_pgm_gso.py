# ** coding: utf-8 **

from typing import Callable

import numpy as np

from models.base import Model


class PGM_GSO(Model):
    def __init__(self, A: np.ndarray, tau, prox_func: Callable):
        super().__init__(A, tau)
        self.m, self.n = self.A.shape
        self.L_np = np.linalg.norm(np.matmul(A.transpose(), A), ord=2)
        self.gamma: np.ndarray = 1 / self.L_np
        self.prox_func: Callable = prox_func
        self.iter_history: list = []

    def forward(self, d, **kwargs) -> np.ndarray:
        K = kwargs.get('K')

        xk = np.zeros([d.shape[0], self.n])

        tau = kwargs.get('tau', self.tau)
        for i in range(K):
            r = (self.A @ xk.T).T - d
            xk = xk -  (self.A.T @ r.T).T

            xk = self.prox_func(xk, self.gamma * tau)  # new

            self.iter_history.append(xk)
        return xk

    def model_name(self) -> str:
        print('PGM_GSO')
        return 'PGM_GSO'

    def proximal_operator_name(self) -> str:
        print(self.prox_func.__name__)
        return self.prox_func.__name__

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
