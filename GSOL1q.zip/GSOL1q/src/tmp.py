import matplotlib.pyplot as plt
from cycler import cycler

# Cell研究所的科研配色
cell_palette = {
    'bright': ['#0076BB', '#FF6666', '#00B572', '#E8C162', '#7F0078', '#0076BB', '#FF6666', '#00B572', '#E8C162',
               '#7F0078'],
    'muted': ['#4285F4', '#DB4437', '#0F9D58', '#F4B400', '#4285F4', '#DB4437', '#0F9D58', '#F4B400', '#4285F4',
              '#DB4437']
}


# 设置Matplotlib的配色方案
def set_cell_palette(palette='muted'):
    colors = cell_palette[palette]
    plt.rcParams['axes.prop_cycle'] = cycler('color', colors)


# 使用配色方案
set_cell_palette('bright')
plt.plot([1, 2, 3, 4], [10, 20, 25, 30])
plt.show()