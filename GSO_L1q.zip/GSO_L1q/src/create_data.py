# ** coding: utf-8 **
import numpy as np


def create_sc_dataset(opts=None):
    if opts is None:
        from config import Opts
        opts = Opts
    np.random.seed(opts.data_seed)
    m, n = opts.m, opts.n
    sparsity = opts.sparsity
    gLen = opts.gLen
    gNo = int(opts.n / gLen)

    test_size = opts.data_size

    A = np.random.normal(0, 1, (m, n))
    Q, _ = np.linalg.qr(A.T)
    A = Q.T
    gNo1 = np.arange(1, gNo + 1)

    c = np.random.normal(0, 1, (test_size, n, 1))

    for sample in range(c.shape[0]):
        Bs = np.zeros((n, 1))
        ActInd = np.random.choice(gNo1, sparsity, replace=False)
        for i in range(sparsity):
            Bs[((ActInd[i] - 1) * gLen):(ActInd[i] * gLen)] = np.ones((gLen, 1))
        c[sample] = Bs * c[sample]

    if opts.noice_params is not None:
        noise = make_noise_data(opts)
    else:
        noise = 0
    b = A.dot(c) + noise

    # # Transform x and d into tensors
    x_tensor = c[:, :, 0]
    d_tensor = b[:, :, 0].T
    return (x_tensor, d_tensor), A, b  # 测试数据集，观测矩阵A，观测组信号b


def make_true_signal(size):
    pass


def make_noise_data(opts):
    noise_params = opts.noise_params
    m = opts.m
    loc, scale = noise_params.loc, noise_params.scale
    if noise_params.dist == 'normal':
        noise = noise_params.sig * np.random.normal(loc, scale, (m, 1, 1))
    elif noise_params.dist == 'laplace':
        noise = noise_params.sig * np.random.laplace(loc, scale, (m, 1, 1))
    else:
        noise = noise_params.sig * np.random.rand(m)
    print(f'\n-----{noise_params.dist} noise added-----\n')
    return noise
