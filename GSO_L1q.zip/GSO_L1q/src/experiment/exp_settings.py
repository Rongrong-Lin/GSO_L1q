# ** coding: utf-8 **
import time

from munch import DefaultMunch, Munch

from common.enum import DistributionEnum
from config import NoiseParams

__all__ = ['exp1_opts']
exp1_opts = DefaultMunch(
    K=1000,
    objective='RELATIVE',
    tau=0.03,
    m=256,
    n=1024,
    data_size=1,
    dist='normal',
    gLen=8,
    data_seed=1,
    logger=None,
    save_dir='../../output/' + time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime()),
    plot_figs=True,
    noise_params=NoiseParams(
        loc=0,
        scale=1,
        sig=0.001,
        dist=DistributionEnum.RAND
    ),
    algorithm='ISTA',
    repeat_times=4,
    dynamic_settings=[Munch.fromDict({'sparsity': 15})]  # [Munch.fromDict({'sparsity': i}) for i in range(1, 31)]
)

assert exp1_opts.objective == 'RELATIVE'
assert exp1_opts.algorithm == 'ISTA'
