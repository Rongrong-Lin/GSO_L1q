# ** coding: utf-8 **
from munch import DefaultMunch

import utils
from config import init_log, Opts
from create_data import create_sc_dataset
from loss import objective_val
from models import ModelFactory
# from prox.prox import *
import numpy as np
import time
from prox.prox_cl import *

# initial log
opts = Opts()
init_log(opts)

# Create data
(x_test, d_test), A, b = create_sc_dataset(opts=opts)

# Compare Algorithms and Proximal Operators
# prox_21=ProxL2_1(opts.n,opts.gLen)
# prox_1_1over2 = ProxL1_1over2(opts.n, opts.gLen, opts.data_size)
# prox_1_2over3 = ProxL1_2over3(opts.n, opts.gLen, opts.data_size)
# prox_2_1over2 = ProxL2_1over2(opts.n, opts.gLen)
# prox_2_2over3 = ProxL2_2over3(opts.n, opts.gLen)
# prox_2_1 = ProxL2_1(opts.n, opts.gLen)
prox_1_1over2_Fixed = ProxL1_1over2_FixParams(opts.n, opts.gLen, opts.data_size, nu=opts.tau)
# prox_1_2over3_Fixed = ProxL1_2over3_FixParams(opts.n, opts.gLen, opts.data_size, nu=opts.tau)

model_prox_dict = {
    'ISTA': [prox_1_1over2_Fixed]
    # , prox_2_1over2, prox_2_2over3, prox_2_1]  # , prox_1_2over3, prox_2_1over2, prox_2_2over3, prox_2_1],  #
}
name_list = [r"$\ell_{1,1/2}$"]  # r"$\ell_{1,1/2}$", r"$\ell_{1,2/3}$", r"$\ell_{2,1/2}$", r"$\ell_{2,2/3}$",
# r"$\ell_{2,1}$"]  # , r"$\ell_{1,2/3}$", r"$\ell_{2,1/2}$", r"$\ell_{2,2/3}$", r"$\ell_{2,1}$"]

save_model = []
total_results = DefaultMunch()
for model_name, prox_func_list in model_prox_dict.items():

    for prox_func in prox_func_list:
        opts.logger('\n Running {} with {}...\n'.format(model_name, ''))
        desc = model_name + '_' + prox_func.name()
        total_results.__setitem__(desc, [])
        model = ModelFactory().create_model(
            model_name=model_name, A=A, prox_func=prox_func, tau=opts.tau)

        start_time = time.time()
        model(d_test, K=opts.K)
        end = time.time()
        print(end - start_time)

        save_model.append(model)
        for k in range(0, opts.K):
            test_loss = objective_val(model.iter_history[k], d_test, x_test, objective=opts.objective).item()
            testing_loss = np.mean(test_loss)  # Compute the average of the losses
            total_results[desc].append(testing_loss)
        # print('Iteration: {}, Testing Loss: {}'.format(k, testing_loss))
        # opts.logger('Testing losses:')
        # for t_loss in total_results[desc]:
        #     opts.logger('{}'.format(t_loss))

# plot fig
import matplotlib.pyplot as plt

for index, (name, loss) in enumerate(total_results.items()):
    # color = random.choice(plot_color)
    # style= random.choice(plot_styles)

    plt.plot(loss, color=utils.plot_color[index], label=name_list[index])
    plt.yscale('log')
    plt.yticks([10 ** 0, 10 ** -1, 10 ** -2, 10 ** -3],
               [r'$10^{0}$', r'$10^{-1}$', r'$10^{-2}$', r'$10^{-3}$'])
    plt.legend()
    # plt.ylabel(r'$10\rm{log_{10}} \frac{\|x-x^*\|_2}{\|x^*\|_2}$')
# plt.title('Log MNSE via FISTA with different prox operators')
plt.show()
if opts.save_dir is not None:
    plt.savefig(opts.save_dir + '/plot.png')
