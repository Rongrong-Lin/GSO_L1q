# ** coding: utf-8 **
from typing import Callable

import numpy as np

from models.base import Model


class ISTA(Model):

    def __init__(self, A: np.ndarray, tau, prox_func: Callable):
        super().__init__(A, tau)
        self.m, self.n = self.A.shape
        self.L_np = np.linalg.norm(np.matmul(A.transpose(), A), ord=2)
        self.gamma: np.ndarray = 1 / self.L_np
        self.prox_func: Callable = prox_func
        self.iter_history: list = []

    def name(self):
        return f'ISTA with {self.prox_func.__name__}'

    def T(self, x, d, **kwargs):
        tau = kwargs.get('tau', self.tau)
        index = kwargs.get('index', -1)
        assert index >= 0

        r = (self.A @ x.T).T - d
        z = x - (self.A.T @ r.T).T

        Tx = self.prox_func(z,  tau)  # new

        return Tx

    def forward(self, d, **kwargs):
        K = kwargs.get('K')

        xk  = np.zeros([d.shape[0], self.n])
      #  xk  = np.random.random([d.shape[0], self.n])
        for i in range(K):

            xk = self.T(xk, d, index=i)

            self.iter_history.append(xk)
        return xk

    def model_name(self) -> str:
        print('ISTA')
        return 'ISTA'

    def proximal_operator_name(self) -> str:
        print(self.prox_func.__name__)
        return self.prox_func.__name__

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
