# ** coding: utf-8 **
import math
from typing import Callable

import numpy as np

from models.base import Model


class FISTA(Model):

    def __init__(self, A: np.ndarray, tau, prox_func: Callable):
        super().__init__(A, tau)
        self.m, self.n = self.A.shape
        self.L_np = np.linalg.norm(np.matmul(A.transpose(), A), ord=2)
        self.gamma: np.ndarray = 1 / self.L_np
        self.prox_func: Callable = prox_func
        self.iter_history: list = []

    def name(self):
        return f'FISTA with {self.prox_func.__name__}'

    def T(self, x, d, **kwargs):
        tau = kwargs.get('tau', self.tau)
        index = kwargs.get('index', -1)
        assert index >= 0

        r = (self.A @ x.T).T - d
        z = x - (self.A.T @ r.T).T

        Tx = self.prox_func(z, self.gamma * tau)  # new

        return Tx

    def forward(self, d, **kwargs):
        K = kwargs.get('K')

        xk = zk = np.zeros([d.shape[0], self.n])

        tk = 1.0

        for i in range(K):

            x_next = self.T(xk, d, index=i)
            # Process momentum
            t_next = 0.5 + math.sqrt(1.0 + 4.0 * tk ** 2) / 2.0
            z_next = x_next + (tk - 1.0) / t_next * (x_next - xk)
            # print((tk -1.0)/t_next)

            # Process iteration
            xk = x_next
            zk = z_next
            tk = t_next

            self.iter_history.append(xk)
        return xk

    def model_name(self) -> str:
        print('FISTA')
        return 'FISTA'

    def proximal_operator_name(self) -> str:
        print(self.prox_func.__name__)
        return self.prox_func.__name__

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
