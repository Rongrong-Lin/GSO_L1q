from typing import Callable

import numpy as np

from common import T
from .block_fista import FISTA
from .block_ista import ISTA
from .block_pgm_gso import PGM_GSO


class ModelFactory():
    def get_model_list(self):
        return [
            'FISTA',
            'PGM_GSO',
            'ISTA'
        ]

    @staticmethod
    def create_FISTA(A: np.ndarray, tau: T, prox_func: Callable):
        return FISTA(A, tau, prox_func)
    @staticmethod
    def create_PGM_GSO(A: np.ndarray, tau: T, prox_func: Callable):
        return PGM_GSO(A, tau, prox_func)
    @staticmethod
    def create_ISTA(A: np.ndarray, tau: T, prox_func: Callable):
        return ISTA(A, tau, prox_func)
    def create_model(self, model_name: str, *args, **kwargs):
        assert model_name in self.get_model_list()
        return getattr(self, f'create_{model_name}')(*args, **kwargs)
