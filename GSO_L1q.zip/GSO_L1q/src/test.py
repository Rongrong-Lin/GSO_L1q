# ** coding: utf-8 **
import numpy as np
from prox.prox_cl import *

prox_l1_1over2 = ProxL1_1over2(n=2, gLen=2, num_samples=1)


def test_group_l1_1over2():
    nu = 1
    y = np.array([5 / 3, 2 / 3])
    print(f'y={y},nu={nu},obj={prox_l1_1over2.obj(y, y, nu)}', prox_l1_1over2.prox(y, nu))
    y = np.array([5 / 3, 1 / 3])
    print(f'y={y},nu={nu},obj={prox_l1_1over2.obj(y, y, nu)}', prox_l1_1over2.prox(y, nu))

    y = np.array([3 / 2, 1 / 3])
    print(f'y={y},nu={nu},obj={prox_l1_1over2.obj(y, y, nu)}', prox_l1_1over2.prox(y, nu))


test_group_l1_1over2()
