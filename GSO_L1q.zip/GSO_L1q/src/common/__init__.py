from typing import TypeVar

import numpy as np

T = TypeVar('T', int, float, np.ndarray)

