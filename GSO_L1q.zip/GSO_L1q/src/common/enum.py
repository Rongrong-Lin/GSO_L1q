from enum import Enum


class DistributionEnum(Enum):
    LAPLACE = 'laplace'
    RAND = 'rand'
    NORMAL = 'normal'



