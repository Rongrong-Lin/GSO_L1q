# ** coding: utf-8 **
import numpy as np

from common import T
from config import Opts
from prox import ProximalOperator

import warnings
warnings.warn('prox.py contains different kind of functions rather than classes. Use `prox_cl.py` instead.', '', DeprecationWarning)

__all__=['group_l2_1', 'group_l2_2over3', 'group_l2_1over2', 'group_l1_1over2', 'group_l1_2over3']
# Group proximal operators



def group_l2_1(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)
    norm_x = norms

    tao = np.where(norm_x <= v, 0.0, (1 - v / norm_x))

    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l2_2over3(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    # 提取每个子向量并计算范数
    norms = np.stack([np.linalg.norm(subvec, axis=1) for subvec in x_subvectors], axis=0)

    t = (1 / 16 + np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3) + (
            1 / 16 - np.sqrt(1 / 256 - (8 * (v ** 3) / (729 * norms ** 4)))) ** (1 / 3)
    tao = np.where(norms <= 2 * ((2 / 3) * v ** 0.75), 0.0,
                   (1.0 / 8.0) * (np.sqrt(2.0 * t) + (
                       np.sqrt(2.0 / np.sqrt(2.0 * t) - 2.0 * t))) ** 3)

    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l2_1over2(x: np.ndarray, v: np.ndarray):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors = np.split(x, num_subvectors, axis=1)

    # 提取每个子向量并计算norm
    norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)
    norm_x = norms

    break_point = 1.5 * v ** (2 / 3)
    tao = np.where(norm_x <= break_point, 0.0, (2 / 3) * (1.0 + np.cos((2 / 3) *
                                                                       (np.arccos(-3 ** 1.5 / 4 * v * (norm_x ** -1.5)
                                                                                  )))))
    x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(num_subvectors)]
    x = np.concatenate(x_subvectors, axis=1)
    return x


def group_l1_1over2(x: np.ndarray, nu: T):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors_sample = np.split(x, 4, axis=0)
    total = np.array([
        np.array([
            Proxl1_1over2.prox(persample_group[0], nu)
            for persample_group in np.split(sample, num_subvectors, axis=1)
        ])
        for sample in x_subvectors_sample
    ])
    return total.reshape(x.shape[0], x.shape[1])


def group_l1_2over3(x: np.ndarray, nu: T):
    num_subvectors = Opts.n // Opts.gLen
    x_subvectors_sample = np.split(x, 1, axis=0)

    # total=[]
    # for i in x_subvectors_sample:
    #     res = []
    #     x_subvectors_group = np.split(i, num_subvectors, axis=1)
    #     for persample_group in x_subvectors_group:
    #         res.append(Proxl1_2over3.prox(persample_group[0], nu))
    #     total.append(res)
    # return np.array(total).reshape(x.shape[0], x.shape[1])
    total = np.array([
        np.array([
            Proxl1_2over3.prox(persample_group[0], nu)
            for persample_group in np.split(sample, num_subvectors, axis=1)
        ])
        for sample in x_subvectors_sample
    ])
    return total.reshape(x.shape[0], x.shape[1])


class Proxl1_1over2:

    @classmethod
    def obj(cls, y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
        return nu * np.power(ytilde.sum(), 1 / 2) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

    @classmethod
    def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
        # 记录顺序和绝对值，用于后续计算
        sign_x = np.sign(x)
        x_abs = x.__abs__()
        indices = np.argsort(x_abs)[::-1]
        sorted_indices = np.argsort(indices)

        # 使用索引获取排序后的矩阵
        y = x_abs[indices]  # STANDARD先绝对值，后降序排序

        condition_1 = 3 * nu ** (2 / 3) / (2 ** (4 / 3))
        condition_2 = 1.5 * nu ** (2 / 3)
        ys_l1 = y.sum()
        if ys_l1 <= condition_1:  # case1
            return np.zeros_like(x)
        elif y[-1] > condition_2:  # case2
            ytilde = y - cls._calculate_cs(ys_l1, nu, len(y))
            return cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
        else:
            # Search s
            s_list = [np.zeros_like(y)]
            s_list.extend(cls._loop_search_s(y, nu))
            Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
            if y[0] <= condition_2:  # case 3
                return cls._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
            else:  # case4
                # if len(s_list)>1:
                #     s_list.pop(0)
                #     Js_list.pop(0)
                return cls._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

    @classmethod
    def _rearrange_org(cls, ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
        return ytilde[sorted_indices] * sign

    @classmethod
    def _loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
        # Search s
        y_l1_array = y.cumsum()

        s_arange = np.arange(1, len(y_l1_array) + 1)
        cs_array = cls._calculate_cs(y_l1_array, nu, s_arange)  # y -> y_s
        y_plus = np.append(y, -1)[1:]

        condition4 = (3 * nu ** (2 / 3) * (0.5 ** (4 / 3))) * s_arange ** (2 / 3)

        res = (y_l1_array >= condition4) & (y_l1_array >= cls._calculate_condition3(v=nu, q=1 / 2, s=s_arange)) & (
                y > cs_array) & (cs_array >= y_plus)
        s_list = [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]
        return s_list

    @classmethod
    def _calculate_cs(cls, y_l1_array: np.ndarray, nu: np.ndarray, s) -> np.ndarray:
        return (np.sqrt(3.0) * nu) / (
                4 * np.sqrt(y_l1_array) * np.cos(
            (1 / 3) * np.arccos(-3 * np.sqrt(3.0) * nu * s * np.power(y_l1_array, -3 / 2) / 4)))

    @classmethod
    def _calculate_condition3(cls, v, q, s):
        return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))


class Proxl1_2over3():

    @classmethod
    def obj(cls, y: np.ndarray, ytilde: np.ndarray, nu: T) -> np.ndarray:
        return nu * np.power(ytilde.sum(), 2 / 3) + 0.5 * (np.linalg.norm(y - ytilde, 2) ** 2)

    @classmethod
    def prox(cls, x: np.ndarray, nu: T) -> np.ndarray:
        # 记录顺序和绝对值，用于后续计算
        sign_x = np.sign(x)
        x_abs = x.__abs__()
        indices = np.argsort(x_abs)[::-1]
        sorted_indices = np.argsort(indices)

        # 使用索引获取排序后的矩阵
        y = x_abs[indices]

        condition_1 = 4 * ((2 / 9) ** 0.75) * (nu ** 0.75)
        condition_2 = 2 * (2 * nu / 3) ** 0.75
        y_l1 = y.sum()
        if y_l1 <= condition_1:  # case1
            return np.zeros_like(x)
        elif y[-1] > condition_2:  # case2
            ytilde = y - cls._calculate_cs(y_l1, nu, len(y))
            return cls._rearrange_org(ytilde, sorted_indices, sign_x)  # 先返回原始顺序，再去除绝对值
        else:
            # Search s
            s_list = [np.zeros_like(y)]
            s_list.extend(cls._loop_search_s(y, nu))
            Js_list = [cls.obj(y, per_ytilde, nu) for per_ytilde in s_list]
            if y[0] <= condition_2:  # case 3
                return cls._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)
            else:  # case4
                # if len(s_list)>1:
                #     s_list.pop(0)
                #     Js_list.pop(0)
                return cls._rearrange_org(s_list[1:][np.argmin(Js_list[1:])], sorted_indices, sign_x)

    @classmethod
    def _rearrange_org(cls, ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
        return ytilde[sorted_indices] * sign

    @classmethod
    def _loop_search_s(cls, y: np.ndarray, nu: np.ndarray) -> list[np.ndarray]:
        # Search s
        y_l1_array = y.cumsum()

        s_arange = np.arange(1, len(y_l1_array) + 1)
        cs_array = cls._calculate_cs(y_l1_array, nu, s_arange)
        y_plus = np.append(y, -1)[1:]

        condition4 = ((4 / 3) * nu ** 0.75 * (2 ** 0.75 / 3 ** 0.5)) * s_arange * 0.75
        res = np.logical_and(
            np.logical_and(y_l1_array >= condition4,
                           y_l1_array >= cls._calculate_condition3(v=nu, q=2 / 3, s=s_arange)),
            np.logical_and(y > cs_array, cs_array >= y_plus))
        s_list = [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]
        return s_list

    @classmethod
    def _calculate_condition3(cls, v, q, s):
        return (2 - q) * (v * q * s / ((q - 1) ** (1 - q))) ** (1 / (2 - q))

    @classmethod
    def _calculate_cs(cls, y_l1_array: np.ndarray, nu: np.ndarray, s) -> np.ndarray:
        part_alpha = np.sqrt(y_l1_array ** 4 / 256 - 8 * (nu ** 3) * (s ** 3) / 729)
        alpha_s = (y_l1_array ** 2 / 16 + part_alpha) ** (1 / 3) + (y_l1_array ** 2 / 16 - part_alpha) ** (1 / 3)
        sqrt_2alpha = np.sqrt(2 * alpha_s)
        return (4 * nu / 3) * 1 / (sqrt_2alpha + np.sqrt(2 * y_l1_array / sqrt_2alpha - 2 * alpha_s))


"""
# def group_l1_1over2(x: np.ndarray, nu: float) -> np.ndarray:
#     num_subvectors = Opts.n // Opts.gLen
#     num_samples = x.shape[0]
#
#     # 预分配一个二维数组，形状为 (num_samples, Opts.n)
#     total = np.empty((num_samples, Opts.n), dtype=x.dtype)
#
#     # 处理每个样本
#     for i in range(num_samples):
#         sample = x[i:i + 1]  # 获取当前样本
#         x_subvectors_group = np.split(sample, num_subvectors, axis=1)
#
#         # 使用向量化处理
#         total[i] = np.concatenate([
#             Proxl1_1over2.prox(persample_group[0], nu) for persample_group in x_subvectors_group
#         ])
#
#     return total
"""
