from abc import ABCMeta
import numpy as np
from common import T

__all__ = ['ProximalOperator', 'GroupProximalOperator']


class ProximalOperator(metaclass=ABCMeta):
    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        raise NotImplementedError

    @classmethod
    def prox(cls, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        raise NotImplementedError

    @classmethod
    def name(cls):
        return cls.__name__

    def __call__(self, *args, **kwargs):
        return self.prox(*args, **kwargs)


class GroupProximalOperator(ProximalOperator):
    n: int
    gLen: int
    num_subvectors: int
    num_samples: int

    __slots__ = ('n', 'gLen', 'num_subvectors', 'num_samples')

    @staticmethod
    def get_num_subvectors(n: int, gLen: int) -> int:
        return n // gLen

    @classmethod
    def obj(cls, x: np.ndarray, xtilde: np.ndarray, nu: T) -> np.ndarray:
        pass

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        """ calculate the proximal operator

        :param x: np.ndarray, the input vector(matrix)
        :param v: T, the threshold
        :param args: None        :param kwargs: None
        :return: np.ndarray, the proximal operator result
        """
        pass

    @classmethod
    def name(cls):
        pass

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        raise NotImplementedError

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        raise NotImplementedError

    def __call__(self, *args, **kwargs):
        return super().__call__(*args, **kwargs)
