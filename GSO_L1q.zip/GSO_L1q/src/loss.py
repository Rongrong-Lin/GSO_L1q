import numpy as np


def objective_val(x, d, x_gt, objective: str = None):
    # Objective function
    if objective == 'GT':
        val = ((x - x_gt) ** 2).sum(dim=1).mean()

    elif objective == 'NMSE':
        l2 = ((x - x_gt) ** 2).mean()
        denom = (x_gt ** 2).mean()
        val = 10.0 * np.log10(l2 / denom)
    elif objective == 'RELATIVE':
        l2 = ((x - x_gt) ** 2).mean()
        denom = (x_gt ** 2).mean()
        val = l2 / denom
    else:
        raise ValueError('Invalid objective option {}'.format(objective))

    return val
